Algoritmo ejercicio_1
	// Realizar un programa que informe si un n�mero es POSITIVO o NEGATIVO.
	definir num Como Real;
	
	Escribir "Ingrese un n�mero";
	Leer num;
	
	Si num > 0 Entonces
		Escribir "El n�mero ingresado es positivo: ",num;
	SiNo
		Si num < 0 Entonces
			Escribir "El n�mero ingresado es negativo: ",num;
		Sino
			Escribir "El n�mero ingresado no es ni positivo ni negativo, es: ", num;
		FinSi
	Fin Si
FinAlgoritmo