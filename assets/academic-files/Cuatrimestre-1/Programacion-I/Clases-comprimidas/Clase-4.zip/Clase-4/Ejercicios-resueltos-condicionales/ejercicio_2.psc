Algoritmo ejercicio_2
	// Realizar un programa que informe si un n�mero es PAR o IMPAR. Precondici�n:No se ingresa Cero.
	Definir num Como Real;
	
	Escribir "Ingrese un n�mero que no sea cero";
	Leer num;
	
	Si num == 0 Entonces
		Escribir "N�mero invalido: ", num;
	SiNo
		Si num % 2 = 0 Entonces
			Escribir "El n�mero ingresado es par: ",num;
		SiNo
			Escribir "El n�mero ingresado es impar: ",num;
		FinSi
	FinSi
FinAlgoritmo