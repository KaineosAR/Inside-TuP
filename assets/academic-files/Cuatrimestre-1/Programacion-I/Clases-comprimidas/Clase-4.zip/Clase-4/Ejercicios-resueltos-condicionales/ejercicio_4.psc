Algoritmo ejercicio_4
	// N�mero de la suerte: Realizar un algoritmo que eval�e si un n�mero ingresado por el usuario es n�mero de la suerte. 
	// Para ser n�mero de la suerte, el n�mero debe ser positivo, impar, y m�ltiplo de 3. 
	// Tambi�n si el n�mero es 20 o 80 es n�mero de la suerte. 
	// Se solicita que esta l�gica se encuentre en un solo condicional.
	Definir num Como Entero;
	
	Escribir "Ingresar n�mero entero"; // El m�dulo (%) no acepta laburar con n�meros reales
	Leer num;
	
	Si ((num > 0) Y (num % 2 <> 0) Y (num % 3 = 0)) O (num == 20) O (num == 80) Entonces
		Escribir "El n�mero ingresado es de la suerte: ",num;
	SiNo
		Escribir "El n�mero ingresado no es de la suerte: ",num;
	FinSi
FinAlgoritmo