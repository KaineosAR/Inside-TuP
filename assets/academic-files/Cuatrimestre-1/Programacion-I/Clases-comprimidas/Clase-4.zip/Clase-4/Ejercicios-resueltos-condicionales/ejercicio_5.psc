Algoritmo ejercicio_5
	// Realizar un programa que solicite dos n�meros al usuario.
    // Luego que le consulte qu� operaci�n desea realizar sobre esos n�meros, pudiendo ser: 
    // 1: Suma, 2: Resta, 3: Multiplicaci�n y 4: Divisi�n. 
	// En funci�n de la selecci�n del usuario, se debe devolver el resultado. 
	// Si el usuario elige otra opci�n, se debe dar el mensaje de que la opci�n no es v�lida.
	Definir numOne, numTwo, total Como Real;
	Definir operation Como Caracter;
	Definir flag Como Logico;
	flag = Verdadero;
	
	Escribir "Ingrese el primer n�mero";
	Leer numOne;
	Escribir "Ingrese el segundo n�mero";
	Leer numTwo;
	Escribir "Ingrese operador (+, -, *, /)";
	Leer operation;
	
	Segun operation Hacer
		"+":
			total = numOne + numTwo;
			Escribir "Operaci�n elegida: Suma";
		"-":
			total = numOne - numTwo;
			Escribir "Operaci�n elegida: Resta";
		"*":
			total = numOne * numTwo;
			Escribir "Operaci�n elegida: Multiplicaci�n";
		"/":
			Si numTwo == 0 Entonces
				flag = Falso;
				Escribir "Operaci�n no v�lida, el segundo n�mero ingresado es 0 y PSeInt no lo permite";
			SiNo
				total = numOne / numTwo;
				Escribir "Operaci�n elegida: Divisi�n";
			FinSi
		De Otro Modo:
			flag = Falso;
			Escribir "Operaci�n no v�lida";
	Fin Segun
	
	Si flag Entonces
		Escribir "Resultado: ",total;
	FinSi
FinAlgoritmo