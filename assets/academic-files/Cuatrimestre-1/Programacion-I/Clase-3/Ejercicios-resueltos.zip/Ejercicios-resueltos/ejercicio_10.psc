Algoritmo ejercicio_10
	// Ejercicio 10� - Se desea calcular su sueldo mensual para lo cual sabe que se aplica la siguiente f�rmula:
	// Sueldo Neto + Salario Familiar + Antig�edad
	// El salario familiar es un monto fijo por cada hijo (fijar uno a elecci�n), y la antig�edad un monto fijo por
	// cada a�o trabajado.
	Definir salaryNet, salaryFam, antique, salaryMonthly, salaryAnnual, hijos Como Real;
	salaryFam = 91218;
	salaryAnnual = 20070925;
	
	Escribir "Insertar sueldo neto";
	Leer salaryNet;
	Escribir "Insertar antig�edad";
	Leer antique;
	Escribir "Insertar hijos";
	Leer hijos;
	
	salaryMonthly = salaryNet + (salaryFam * hijos) + (antique * salaryAnnual);
	Escribir "Sueldo mensual: ",salaryMonthly;
FinAlgoritmo