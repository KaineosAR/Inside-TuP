Algoritmo ejercicio_5
	// Ejercicio 5� - Dados una terna de n�meros naturales que representan al d�a, al mes y al a�o de una determinada
	// fecha informarla como un solo n�mero natural de 8 d�gitos con la forma (AAAAMMDD).
	// F�rmula: A�o * 10000 + Mes * 100 + D�a
	Definir dia, mes, a�o, final Como Entero;
	
	Escribir "Introducir d�a";
	Leer dia;
	Escribir "Introducir mes";
	Leer mes;
	Escribir "Introducir a�o";
	Leer a�o;
	
	final = (a�o * 10000) + (mes * 100) + dia;
	
	Escribir "Resultado en AAAAMMDD: ",final;
FinAlgoritmo