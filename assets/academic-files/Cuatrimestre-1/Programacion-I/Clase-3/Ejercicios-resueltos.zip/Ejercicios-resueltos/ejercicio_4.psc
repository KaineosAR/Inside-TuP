Algoritmo ejercicio_4
	// Ejercicio 4� - Dado el radio de un c�rculo calcular e informar:
	// a) El �rea del c�rculo (se obtiene multiplicando el radio al cuadrado por el n�mero Pi)
	// b) El per�metro del c�rculo (se obtiene multiplicando el di�metro por el n�mero Pi)
	Definir radio, diame Como Entero; // Podr�an ser Reales, posible optimizaci�n
	Definir area, perim Como Real;
	
	Escribir "Ingresar radio del c�rculo";
	Leer radio;
	Escribir "Ingresar di�metro del c�rculo";
	Leer diame;
	
	area = PI * radio^2;
	perim = PI * diame;
	
	Escribir "Resutados:";
	Escribir "�rea = ",area;
	Escribir "Per�metro = ",perim;
FinAlgoritmo