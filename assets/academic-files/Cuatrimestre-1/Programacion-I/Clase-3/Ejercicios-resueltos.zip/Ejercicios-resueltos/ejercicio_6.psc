Algoritmo ejercicio_6
	// Ejercicio 6� - Dada un n�mero entero de la forma (AAAAMMDD), que representa una fecha valida mostrar
	// el d�a, mes y a�o que representa.
	Definir fecha, dia, mes, a�o Como Entero;
	
	Escribir "Introducir AAAAMMDD";
	Leer fecha;
	
	a�o = trunc(fecha / 10000);
	mes = trunc((fecha % 10000) / 100);
	dia = fecha % 100;
	
	Escribir "Resultados:";
	Escribir "D�a: ",dia;
	Escribir "Mes: ",mes;
	Escribir "A�o: ",a�o;
FinAlgoritmo